# Simple HTML Page with Toast Notifications using Toastr

A Pen created on CodePen.io. Original URL: [https://codepen.io/technoloG/pen/bBWgae](https://codepen.io/technoloG/pen/bBWgae).

