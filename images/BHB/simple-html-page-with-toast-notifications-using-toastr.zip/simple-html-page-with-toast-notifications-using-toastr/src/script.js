$(document).ready(init);

function init(jQuery) {
  CurrentYear();
}

function CurrentYear() {
  var thisYear = new Date().getFullYear()
  $("#currentYear").text(thisYear);
}


// Event Handlers
document.getElementById("btnInfo").onclick = infoClick;
document.getElementById("btnSuccess").onclick = successClick;
document.getElementById("btnWarning").onclick = warningClick;
document.getElementById("btnError").onclick = errorClick;

function infoClick() {
  var title = document.getElementById("txtTitle").value;
  var message = document.getElementById("txtMessage").value;
  
  notifyInfo(title, message);
}

function successClick() {
  var title = document.getElementById("txtTitle").value;
  var message = document.getElementById("txtMessage").value;
  
  notifySuccess(title, message);
}

function warningClick() {
  var title = document.getElementById("txtTitle").value;
  var message = document.getElementById("txtMessage").value;
  
  notifyWarning(title, message);
}

function errorClick() {
  var title = document.getElementById("txtTitle").value;
  var message = document.getElementById("txtMessage").value;
  
  notifyError(title, message);
}


// Toastr
function notifyInfo(title, msg) {
  // Display an info toast with no title
  toastr.info(msg, title);
}

function notifySuccess(title, msg) {
  // Display a success toast with no title
  toastr.success(msg, title);
}

function notifyWarning(title, msg) {
  // Display a warning toast with no title
  toastr.warning(msg, title);
}

function notifyError(title, msg) {
  // Display a warning toast with no title
  toastr.error(msg, title);
}
