# Responsive Table with RWD-Table-Patterns

A Pen created on CodePen.io. Original URL: [https://codepen.io/SitePoint/pen/OPKvwm](https://codepen.io/SitePoint/pen/OPKvwm).

